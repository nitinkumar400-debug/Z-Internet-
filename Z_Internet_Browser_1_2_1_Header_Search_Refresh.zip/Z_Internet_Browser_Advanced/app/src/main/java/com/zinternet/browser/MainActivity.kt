package com.zinternet.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.setPadding
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private data class BrowserTab(val web: WebView, var url: String, val privateMode: Boolean)
    private val tabs = mutableListOf<BrowserTab>()
    private var active = 0
    private lateinit var root: LinearLayout
    private lateinit var address: TextInputEditText
    private lateinit var webHost: FrameLayout
    private lateinit var tabLabel: TextView
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("z_internet", MODE_PRIVATE) }
    private val history get() = prefs.getStringSet("history", emptySet())!!.toMutableSet()
    private val bookmarks get() = prefs.getStringSet("bookmarks", emptySet())!!.toMutableSet()
    private var dark = false
    private var desktop = false
    private var adBlock = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", false)
        desktop = prefs.getBoolean("desktop", false)
        adBlock = prefs.getBoolean("adblock", true)
        AppCompatDelegate.setDefaultNightMode(if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        buildShell()
        newTab("https://www.google.com", false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(text: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            isAllCaps = false
            cornerRadius = dp(16)
            setOnClickListener { onClick() }
        }

    private fun buildShell() {
        val pageBg = if (dark) Color.rgb(10, 18, 34) else Color.rgb(244, 247, 253)
        val surface = if (dark) Color.rgb(25, 37, 58) else Color.WHITE
        val primary = Color.rgb(31, 105, 224)
        val textMain = if (dark) Color.WHITE else Color.rgb(24, 39, 64)
        val textMuted = if (dark) Color.rgb(170, 185, 207) else Color.rgb(105, 119, 143)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pageBg)
            setPadding(dp(14), dp(22), dp(14), dp(18))
        }

        // Single-line browser title with compact theme toggle
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(7), dp(3), dp(13))
        }
        val brandText = TextView(this).apply {
            text = "Z-Internet"
            textSize = 23f
            setTextColor(textMain)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        header.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button(if (dark) "☀" else "☾") {
            dark = !dark
            prefs.edit().putBoolean("dark", dark).apply()
            recreate()
        }.apply {
            textSize = 17f
            minWidth = dp(42)
            minimumWidth = dp(42)
            setPadding(dp(2), 0, dp(2), 0)
        })
        root.addView(header)

        // Search field with refresh control beside it
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val addressCard = MaterialCardView(this).apply {
            radius = dp(22).toFloat()
            cardElevation = dp(2).toFloat()
            strokeWidth = dp(1)
            strokeColor = if (dark) Color.rgb(55, 76, 108) else Color.rgb(225, 233, 246)
            setCardBackgroundColor(surface)
        }
        val addressRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(13), 0, dp(7), 0)
        }
        addressRow.addView(TextView(this).apply {
            text = "⌕"
            textSize = 25f
            setTextColor(primary)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(30), dp(50)))
        address = TextInputEditText(this).apply {
            hint = "Search or enter website"
            setSingleLine(true)
            textSize = 15f
            setTextColor(textMain)
            setHintTextColor(textMuted)
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(5), 0, dp(5), 0)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(text?.toString().orEmpty()); true
                } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(52), 1f))
        addressRow.addView(button("GO") {
            navigate(address.text?.toString().orEmpty())
        }.apply {
            textSize = 12f
            cornerRadius = dp(16)
            setBackgroundColor(primary)
        })
        addressCard.addView(addressRow)
        searchRow.addView(addressCard, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(button("⟳") { tabs.getOrNull(active)?.web?.reload() }.apply {
            textSize = 23f
            minWidth = dp(43)
            minimumWidth = dp(43)
            setPadding(0, 0, 0, 0)
        }, LinearLayout.LayoutParams(dp(47), dp(50)).apply { marginStart = dp(5) })
        root.addView(searchRow)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(primary)
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)).apply {
            topMargin = dp(5)
            bottomMargin = dp(4)
        })

        // Web content takes the available space
        webHost = FrameLayout(this)
        root.addView(webHost, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(7)
            bottomMargin = dp(8)
        })

        // One compact bottom toolbar: Back, Save, Bookmarks, New, Tabs, Settings
        val bottomCard = MaterialCardView(this).apply {
            radius = dp(22).toFloat()
            cardElevation = dp(3).toFloat()
            strokeWidth = dp(1)
            strokeColor = if (dark) Color.rgb(55, 76, 108) else Color.rgb(225, 233, 246)
            setCardBackgroundColor(surface)
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        val bottomItems: List<Pair<String, () -> Unit>> = listOf(
            "‹" to { goBack() },
            "☆" to { addCurrentBookmark() },
            "★" to { showBookmarks() },
            "＋" to { newTab("https://www.google.com", false) },
            "▢" to { showTabs() },
            "⚙" to { showMenu() }
        )
        val descriptions = listOf("Back", "Add bookmark", "Bookmarks", "New window", "Multi windows", "Settings")
        bottomItems.forEachIndexed { index, item ->
            val icon = TextView(this).apply {
                text = item.first
                textSize = if (index == 5) 23f else 27f
                gravity = Gravity.CENTER
                setTextColor(if (index == 3) primary else textMain)
                contentDescription = descriptions[index]
                isClickable = true
                isFocusable = true
                setOnClickListener { item.second() }
            }
            toolbar.addView(icon, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        bottomCard.addView(toolbar)
        root.addView(bottomCard)

        tabLabel = TextView(this).apply {
            visibility = View.GONE
        }
        root.addView(tabLabel)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(privateMode: Boolean): WebView = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.cacheMode = if (privateMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this@MainActivity).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this@MainActivity)
        if (privateMode) {
            clearCache(true)
            clearHistory()
            settings.saveFormData = false
        }
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) return false
                return true
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock && !privateMode) {
                    val host = request?.url?.host?.lowercase().orEmpty()
                    if (blockedHosts.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), null)
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                this@MainActivity.progress.visibility = View.VISIBLE
                this@MainActivity.progress.progress = 5
                address.setText(url.orEmpty())
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                this@MainActivity.progress.visibility = View.GONE
                url?.let {
                    val tab = tabs.getOrNull(active)
                    if (tab != null && tab.web === view) tab.url = it
                    if (tab != null && !tab.privateMode) saveHistory(it)
                    address.setText(it)
                }
                updateTabLabel()
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                this@MainActivity.progress.progress = newProgress
                this@MainActivity.progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
            override fun onReceivedTitle(view: WebView?, title: String?) { updateTabLabel(title) }
        }
        setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimeType)
                request.addRequestHeader("User-Agent", settings.userAgentString)
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                request.setDescription("Downloading with Z-Internet")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this@MainActivity, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Download failed", Toast.LENGTH_SHORT).show() }
        }
    }

    private val blockedHosts = setOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "ads.yahoo.com", "adnxs.com", "taboola.com", "outbrain.com")
    private fun newTab(url: String, privateMode: Boolean) {
        val web = createWebView(privateMode)
        tabs.add(BrowserTab(web, url, privateMode))
        switchTab(tabs.lastIndex)
        web.loadUrl(url)
    }
    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        active = index
        webHost.removeAllViews()
        val web = tabs[index].web
        (web.parent as? ViewGroup)?.removeView(web)
        webHost.addView(web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tabs[index].url)
        updateTabLabel()
    }
    private fun navigate(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") -> "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
            else -> "https://$value"
        }
        tabs.getOrNull(active)?.let { it.url = url; it.web.loadUrl(url) }
    }
    private fun goBack() { tabs.getOrNull(active)?.web?.let { if (it.canGoBack()) it.goBack() else Toast.makeText(this, "No previous page", Toast.LENGTH_SHORT).show() } }
    private fun goForward() { tabs.getOrNull(active)?.web?.let { if (it.canGoForward()) it.goForward() else Toast.makeText(this, "No next page", Toast.LENGTH_SHORT).show() } }
    private fun updateTabLabel(title: String? = null) {
        tabLabel.text = "${title ?: tabs.getOrNull(active)?.web?.title ?: "New tab"}   •   ${active + 1}/${tabs.size}" +
            if (tabs.getOrNull(active)?.privateMode == true) "   •   Incognito" else ""
    }
    private fun saveHistory(url: String) {
        if (!url.startsWith("http")) return
        val set = history
        set.add(url)
        prefs.edit().putStringSet("history", set).apply()
    }
    private fun toggleBookmark() {
        val url = tabs.getOrNull(active)?.url ?: return
        val set = bookmarks
        if (!set.add(url)) set.remove(url)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, if (url in set) "Bookmarked" else "Bookmark removed", Toast.LENGTH_SHORT).show()
    }
    private fun addCurrentBookmark() {
        val tab = tabs.getOrNull(active) ?: return
        val url = tab.url
        if (!url.startsWith("http")) {
            Toast.makeText(this, "पहले कोई वेबसाइट खोलें", Toast.LENGTH_SHORT).show()
            return
        }
        val set = bookmarks
        val added = set.add(url)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, if (added) "Bookmark saved" else "यह पहले से Bookmark में है", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val saved = bookmarks.toList().sorted()
        if (saved.isEmpty()) {
            Toast.makeText(this, "अभी कोई Bookmark नहीं है", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Bookmarks")
            .setItems(saved.toTypedArray()) { _, which -> navigate(saved[which]) }
            .setNeutralButton("Clear all") { _, _ ->
                prefs.edit().remove("bookmarks").apply()
                Toast.makeText(this, "Bookmarks cleared", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openDownloads() {
        try {
            startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (_: Exception) {
            Toast.makeText(this, "Downloads इस डिवाइस पर उपलब्ध नहीं हैं", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showTabs() {
        val names = tabs.mapIndexed { i, t -> "${i + 1}. ${t.web.title ?: t.url}" + if (t.privateMode) " (Incognito)" else "" }.toMutableList()
        names.add("＋ New tab")
        AlertDialog.Builder(this).setTitle("Tabs (${tabs.size})").setItems(names.toTypedArray()) { _, which ->
            if (which == tabs.size) newTab("https://www.google.com", false) else switchTab(which)
        }.setNeutralButton("Close current") { _, _ -> closeCurrentTab() }.show()
    }
    private fun closeCurrentTab() {
        if (tabs.size <= 1) { tabs[0].web.loadUrl("https://www.google.com"); tabs[0].url = "https://www.google.com"; return }
        val removed = tabs.removeAt(active)
        webHost.removeView(removed.web)
        removed.web.stopLoading(); removed.web.destroy()
        active = (active - 1).coerceAtLeast(0)
        switchTab(active)
    }
    private fun showList(title: String, values: Set<String>) {
        val items = values.toList().sortedDescending()
        if (items.isEmpty()) { Toast.makeText(this, "Nothing here yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which -> navigate(items[which]) }
            .setPositiveButton("Clear") { _, _ ->
                if (title == "History") prefs.edit().remove("history").apply()
                if (title == "Bookmarks") prefs.edit().remove("bookmarks").apply()
            }.show()
    }
    private fun showMenu() {
        val items = arrayOf("New incognito tab", "Bookmarks", "History", "Downloads", "Desktop site: ${if (desktop) "ON" else "OFF"}", "Ad blocking: ${if (adBlock) "ON" else "OFF"}", "Dark mode: ${if (dark) "ON" else "OFF"}", "Settings / About")
        AlertDialog.Builder(this).setTitle("Z-Internet menu").setItems(items) { _, which ->
            when (which) {
                0 -> newTab("https://www.google.com", true)
                1 -> showList("Bookmarks", bookmarks)
                2 -> showList("History", history)
                3 -> startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                4 -> { desktop = !desktop; prefs.edit().putBoolean("desktop", desktop).apply(); reloadWithSettings() }
                5 -> { adBlock = !adBlock; prefs.edit().putBoolean("adblock", adBlock).apply(); Toast.makeText(this, "Ad blocking ${if (adBlock) "on" else "off"}", Toast.LENGTH_SHORT).show() }
                6 -> { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); recreate() }
                7 -> showSettings()
            }
        }.show()
    }
    private fun reloadWithSettings() {
        tabs.forEach { tab ->
            val url = tab.url
            tab.web.settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this)
            tab.web.reload()
        }
    }
    private fun showSettings() {
        AlertDialog.Builder(this).setTitle("Z-Internet Browser")
            .setMessage("Version 1.0.0\\n\\nAdvanced Android browser built with WebView. Includes tabs, bookmarks, history, downloads, incognito sessions, desktop user-agent mode and basic request blocking.\\n\\nNote: request blocking uses a small built-in domain list; it is not a full filter-list ad blocker.")
            .setPositiveButton("OK", null).show()
    }
    override fun onBackPressed() {
        val web = tabs.getOrNull(active)?.web
        if (web?.canGoBack() == true) web.goBack() else if (tabs.size > 1) closeCurrentTab() else super.onBackPressed()
    }
    override fun onDestroy() {
        tabs.forEach { it.web.stopLoading(); it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }
}
