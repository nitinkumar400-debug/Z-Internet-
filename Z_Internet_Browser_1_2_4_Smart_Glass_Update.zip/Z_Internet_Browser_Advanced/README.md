# Z-Internet Browser

Advanced Android WebView browser starter project.

## Included
- Multi-tab browsing and tab switcher
- Search/address bar (Google search by default)
- Bookmarks and browsing history
- DownloadManager integration
- Incognito tabs (session-only browsing, no app history persistence)
- Desktop user-agent toggle
- Light/dark appearance
- Basic request blocking using a small built-in domain list
- GitHub Actions workflow to build a debug APK

## Build locally
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build APK(s).

## Build on GitHub
Push the project to a GitHub repository. Open Actions and run **Z-Internet Android APK**, or push to main/master. Download `Z-Internet-debug-apk` from the workflow run's Artifacts.

## Important limitations
This is a first advanced MVP. The built-in blocker is a small domain list, not a complete filter-list engine. Incognito uses an isolated non-persistent WebView configuration but Android WebView may retain transient data during the active session; closing the tab destroys that WebView. No VPN-level blocking, sync, password manager, or extension system is included.
