package com.zinternet.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.WindowManager
import android.widget.ImageView
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.setPadding
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private data class BrowserTab(val web: WebView, var url: String, val privateMode: Boolean)
    private val tabs = mutableListOf<BrowserTab>()
    private var active = 0
    private lateinit var root: LinearLayout
    private lateinit var address: TextInputEditText
    private lateinit var webHost: FrameLayout
    private lateinit var tabLabel: TextView
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("z_internet", MODE_PRIVATE) }
    private val history get() = prefs.getStringSet("history", emptySet())!!.toMutableSet()
    private val bookmarks get() = prefs.getStringSet("bookmarks", emptySet())!!.toMutableSet()
    private var dark = false
    private var desktop = false
    private var adBlock = true
    private val siteIcons = mutableMapOf<String, android.graphics.Bitmap>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", false)
        desktop = prefs.getBoolean("desktop", false)
        adBlock = prefs.getBoolean("adblock", true)
        AppCompatDelegate.setDefaultNightMode(if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        buildShell()
        newTab("https://www.google.com", false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(text: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            isAllCaps = false
            cornerRadius = dp(16)
            setOnClickListener { onClick() }
        }

    private fun buildShell() {
        val pageBg = if (dark) Color.rgb(10, 18, 34) else Color.rgb(244, 247, 253)
        val surface = if (dark) Color.rgb(25, 37, 58) else Color.WHITE
        val primary = Color.rgb(31, 105, 224)
        val textMain = if (dark) Color.WHITE else Color.rgb(24, 39, 64)
        val textMuted = if (dark) Color.rgb(170, 185, 207) else Color.rgb(105, 119, 143)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (dark) Color.rgb(9, 16, 29) else Color.rgb(231, 239, 252))
            setPadding(dp(14), dp(34), dp(14), dp(18))
        }

        // Search field with refresh control beside it
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val glassFill = if (dark) Color.argb(168, 30, 46, 70) else Color.argb(174, 255, 255, 255)
        val glassStroke = if (dark) Color.argb(115, 150, 180, 220) else Color.argb(150, 255, 255, 255)
        val addressCard = MaterialCardView(this).apply {
            radius = dp(22).toFloat()
            cardElevation = dp(7).toFloat()
            strokeWidth = dp(1)
            strokeColor = glassStroke
            setCardBackgroundColor(glassFill)
            useCompatPadding = true
        }
        val addressRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(13), 0, dp(7), 0)
        }
        addressRow.addView(TextView(this).apply {
            text = "⌕"
            textSize = 25f
            setTextColor(primary)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(30), dp(50)))
        address = TextInputEditText(this).apply {
            hint = "Search or enter website"
            setSingleLine(true)
            textSize = 15f
            setTextColor(textMain)
            setHintTextColor(textMuted)
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(5), 0, dp(5), 0)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(text?.toString().orEmpty()); true
                } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(40), 1f))
        addressRow.addView(button("➜") {
            navigate(address.text?.toString().orEmpty())
        }.apply {
            textSize = 21f
            minWidth = dp(40)
            minimumWidth = dp(40)
            cornerRadius = dp(14)
            setPadding(0, 0, 0, 0)
            setBackgroundColor(primary)
            contentDescription = "Go"
        })
        searchRow.addView(addressCard, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(button("↻") { tabs.getOrNull(active)?.web?.reload() }.apply {
            textSize = 21f
            minWidth = dp(38)
            minimumWidth = dp(38)
            cornerRadius = dp(16)
            setPadding(0, 0, 0, 0)
            contentDescription = "Refresh page"
        }, LinearLayout.LayoutParams(dp(34), dp(36)).apply { marginStart = dp(3) })
        searchRow.addView(button(if (dark) "☀" else "☾") {
            dark = !dark
            prefs.edit().putBoolean("dark", dark).apply()
            recreate()
        }.apply { textSize = 17f; minWidth = dp(34); minimumWidth = dp(34); setPadding(0,0,0,0); contentDescription = "Change theme" }, LinearLayout.LayoutParams(dp(32), dp(36)))
        searchRow.addView(button("−") { tabs.getOrNull(active)?.web?.zoomOut() }.apply {
            textSize = 22f; minWidth = dp(30); minimumWidth = dp(30); setPadding(0,0,0,0); contentDescription = "Zoom out"
        }, LinearLayout.LayoutParams(dp(28), dp(36)))
        searchRow.addView(button("+") { tabs.getOrNull(active)?.web?.zoomIn() }.apply {
            textSize = 20f; minWidth = dp(30); minimumWidth = dp(30); setPadding(0,0,0,0); contentDescription = "Zoom in"
        }, LinearLayout.LayoutParams(dp(28), dp(36)))
        // Progress indicator is overlaid inside the address card.
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(primary)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)
            visibility = View.GONE
        }
        val addressStack = FrameLayout(this)
        addressStack.addView(addressRow, FrameLayout.LayoutParams(-1, -2))
        addressStack.addView(progress, FrameLayout.LayoutParams(-1, dp(2), Gravity.BOTTOM))
        addressCard.removeAllViews()
        addressCard.addView(addressStack)

        // One compact bottom toolbar: Back, Save, Bookmarks, New, Tabs, Settings
        val bottomCard = MaterialCardView(this).apply {
            radius = dp(22).toFloat()
            cardElevation = dp(9).toFloat()
            strokeWidth = dp(1)
            strokeColor = glassStroke
            setCardBackgroundColor(glassFill)
            useCompatPadding = true
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        val bottomItems: List<Pair<String, () -> Unit>> = listOf(
            "‹" to { goBack() },
            "☆" to { addCurrentBookmark() },
            "★" to { showBookmarks() },
            "＋" to { newTab("https://www.google.com", false) },
            "▢" to { showTabs() },
            "⚙" to { showMenu() }
        )
        val descriptions = listOf("Back", "Add bookmark", "Bookmarks", "New window", "Multi windows", "Settings")
        bottomItems.forEachIndexed { index, item ->
            val icon = TextView(this).apply {
                text = item.first
                textSize = if (index == 5) 23f else 27f
                gravity = Gravity.CENTER
                setTextColor(if (index == 3) primary else textMain)
                contentDescription = descriptions[index]
                isClickable = true
                isFocusable = true
                setOnClickListener { item.second() }
            }
            toolbar.addView(icon, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        bottomCard.addView(toolbar)
        root.addView(searchRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        // Web content fills the remaining screen below the top address controls.
        webHost = FrameLayout(this)
        root.addView(webHost, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(3)
            bottomMargin = dp(5)
        })
        root.addView(bottomCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })

        tabLabel = TextView(this).apply {
            visibility = View.GONE
        }
        root.addView(tabLabel)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(privateMode: Boolean): WebView = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.blockNetworkImage = false
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH)
        settings.cacheMode = if (privateMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.databaseEnabled = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.textZoom = prefs.getInt("page_scale", 100).coerceIn(50, 200)
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.cacheMode = if (privateMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this@MainActivity).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this@MainActivity)
        if (privateMode) {
            clearCache(true)
            clearHistory()
            settings.saveFormData = false
        }
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) return false
                return true
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock) {
                    val uri = request?.url
                    val host = uri?.host?.lowercase().orEmpty()
                    val path = uri?.encodedPath?.lowercase().orEmpty()
                    val adPath = listOf("/ads/", "/ad/", "/adserver/", "/advertising/", "/pagead/", "/doubleclick/", "/adsystem/", "/promoted/", "/sponsored/").any { path.contains(it) }
                    if (blockedHosts.any { blockedHost -> host == blockedHost || host.endsWith(".$blockedHost") } || adPath) {
                        return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), null)
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                this@MainActivity.progress.visibility = View.VISIBLE
                this@MainActivity.progress.progress = 5
                address.setText(url.orEmpty())
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                this@MainActivity.progress.visibility = View.GONE
                url?.let {
                    val tab = tabs.getOrNull(active)
                    if (tab != null && tab.web === view) tab.url = it
                    if (tab != null && !tab.privateMode) saveHistory(it)
                    address.setText(it)
                }
                updateTabLabel()
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                this@MainActivity.progress.progress = newProgress
                this@MainActivity.progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
            override fun onReceivedTitle(view: WebView?, title: String?) { updateTabLabel(title) }
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                // Do not create secondary WebViews for popup/ad windows.
                return false
            }
            override fun onReceivedIcon(view: WebView?, icon: android.graphics.Bitmap?) {
                val current = tabs.getOrNull(active)
                if (current != null && current.web === view && icon != null) {
                    siteIcons[current.url] = icon
                }
            }
        }
        setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimeType)
                request.addRequestHeader("User-Agent", settings.userAgentString)
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                request.setDescription("Downloading with Z-Internet")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setAllowedOverMetered(true)
                request.setAllowedOverRoaming(false)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this@MainActivity, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Download failed", Toast.LENGTH_SHORT).show() }
        }
    }

    private val blockedHosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "ads.yahoo.com", "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "popcash.net",
        "propellerads.com", "adsterra.com", "exoclick.com",
        "revenuehits.com", "hilltopads.com", "onclicka.com", "trafficjunky.net", "zedo.com",
        "criteo.com", "scorecardresearch.com", "amazon-adsystem.com", "media.net",
        "adform.net", "adsrvr.org", "serving-sys.com", "smartadserver.com", "lijit.com",
        "casalemedia.com", "advertising.com", "bidswitch.net", "openx.net", "pubmatic.com", "rubiconproject.com", "33across.com", "sharethrough.com"
    )
    private fun newTab(url: String, privateMode: Boolean) {
        val web = createWebView(privateMode)
        tabs.add(BrowserTab(web, url, privateMode))
        switchTab(tabs.lastIndex)
        if (url == "https://www.google.com" || url == "https://www.google.com/") loadMinimalHome(web) else web.loadUrl(url)
    }
    private fun loadMinimalHome(web: WebView) {
        val homeBg = if (dark) "#0a1222" else "#ffffff"
        val homeText = if (dark) "#ffffff" else "#202124"
        val inputBorder = if (dark) "#52627a" else "#dfe1e5"
        val html = """<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, user-scalable=yes"><style>
            *{box-sizing:border-box}body{margin:0;background:$homeBg;color:$homeText;font-family:Arial,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center}
            .wrap{width:100%;padding:24px;text-align:center;margin-top:-8vh}.logo{font-size:clamp(42px,12vw,64px);font-weight:800;letter-spacing:-2px;margin-bottom:34px;text-shadow:0 3px 12px #4285f455}
            .logo span:nth-child(1),.logo span:nth-child(7){color:#4285f4}.logo span:nth-child(2),.logo span:nth-child(8){color:#ea4335}.logo span:nth-child(3),.logo span:nth-child(9){color:#fbbc05}.logo span:nth-child(4),.logo span:nth-child(10){color:#34a853}.logo span:nth-child(5){color:#8b5cf6}.logo span:nth-child(6){color:#f97316}
            form{height:54px;border:1px solid $inputBorder;border-radius:30px;display:flex;align-items:center;padding:0 18px;box-shadow:0 1px 5px #00000012}input{border:0;outline:0;flex:1;min-width:0;font-size:16px;background:transparent;color:$homeText}button{border:0;background:transparent;color:#4285f4;font-size:22px;padding:6px;cursor:pointer}
            </style></head><body><div class="wrap"><div class="logo"><span>C</span><span>h</span><span>a</span><span>u</span><span>d</span><span>h</span><span>a</span><span>r</span><span>y</span></div><form action="https://www.google.com/search" method="get"><input name="q" aria-label="Google Search" autocomplete="off"><button type="submit" aria-label="Search">⌕</button></form></div></body></html>"""
        web.loadDataWithBaseURL("https://www.google.com/", html, "text/html", "UTF-8", null)
    }
    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        active = index
        webHost.removeAllViews()
        val web = tabs[index].web
        (web.parent as? ViewGroup)?.removeView(web)
        webHost.addView(web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tabs[index].url)
        updateTabLabel()
    }
    private fun navigate(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") -> "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
            else -> "https://$value"
        }
        tabs.getOrNull(active)?.let { it.url = url; it.web.loadUrl(url) }
    }
    private fun goBack() { tabs.getOrNull(active)?.web?.let { if (it.canGoBack()) it.goBack() else Toast.makeText(this, "No previous page", Toast.LENGTH_SHORT).show() } }
    private fun goForward() { tabs.getOrNull(active)?.web?.let { if (it.canGoForward()) it.goForward() else Toast.makeText(this, "No next page", Toast.LENGTH_SHORT).show() } }
    private fun updateTabLabel(title: String? = null) {
        tabLabel.text = "${title ?: tabs.getOrNull(active)?.web?.title ?: "New tab"}   •   ${active + 1}/${tabs.size}" +
            if (tabs.getOrNull(active)?.privateMode == true) "   •   Incognito" else ""
    }
    private fun saveHistory(url: String) {
        if (!url.startsWith("http")) return
        val set = history
        set.add(url)
        prefs.edit().putStringSet("history", set).apply()
    }
    private fun toggleBookmark() {
        val url = tabs.getOrNull(active)?.url ?: return
        val set = bookmarks
        if (!set.add(url)) set.remove(url)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, if (url in set) "Bookmarked" else "Bookmark removed", Toast.LENGTH_SHORT).show()
    }
    private fun addCurrentBookmark() {
        val tab = tabs.getOrNull(active) ?: return
        val url = tab.url
        if (!url.startsWith("http")) {
            Toast.makeText(this, "पहले कोई वेबसाइट खोलें", Toast.LENGTH_SHORT).show()
            return
        }
        val set = bookmarks
        val added = set.add(url)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, if (added) "Bookmark saved" else "यह पहले से Bookmark में है", Toast.LENGTH_SHORT).show()
    }

    private fun showBookmarks() {
        val saved = bookmarks.toList().sorted()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(if (dark) Color.argb(238, 24, 38, 59) else Color.argb(242, 247, 250, 255))
                setStroke(dp(1), if (dark) Color.argb(130, 160, 190, 225) else Color.argb(180, 255, 255, 255))
            }
        }
        panel.addView(TextView(this).apply {
            text = "Bookmarks"
            textSize = 21f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(if (dark) Color.WHITE else Color.rgb(24, 39, 64))
            setPadding(0, 0, 0, dp(10))
        })
        if (saved.isEmpty()) {
            panel.addView(TextView(this).apply { text = "अभी कोई Bookmark नहीं है"; setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY) })
        } else {
            val scroll = ScrollView(this)
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            saved.forEach { url ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(5), dp(8), dp(5))
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { navigate(url); dialogRef?.dismiss() }
                }
                val icon = ImageView(this).apply {
                    val bitmap = siteIcons[url]
                    if (bitmap != null) setImageBitmap(bitmap) else setImageResource(android.R.drawable.ic_menu_view)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) })
                row.addView(TextView(this).apply {
                    text = url
                    textSize = 14f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(if (dark) Color.WHITE else Color.rgb(30, 48, 76))
                    gravity = Gravity.CENTER_VERTICAL
                }, LinearLayout.LayoutParams(0, -1, 1f))
                list.addView(row, LinearLayout.LayoutParams(-1, dp(46)))
                val line = View(this).apply { setBackgroundColor(if (dark) Color.argb(55,255,255,255) else Color.argb(45,20,50,90)) }
                list.addView(line, LinearLayout.LayoutParams(-1, dp(1)))
            }
            scroll.addView(list)
            panel.addView(scroll, LinearLayout.LayoutParams(-1, dp(260)))
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val dialog = AlertDialog.Builder(this).setView(panel).setNegativeButton("Close", null)
            .setNeutralButton("Clear all", null).create()
        dialogRef = dialog
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL)?.setOnClickListener {
                prefs.edit().remove("bookmarks").apply(); dialog.dismiss()
                Toast.makeText(this, "Bookmarks cleared", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }
    private var dialogRef: AlertDialog? = null

    private fun openDownloads() {
        try {
            startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (_: Exception) {
            Toast.makeText(this, "Downloads इस डिवाइस पर उपलब्ध नहीं हैं", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showTabs() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
            setBackgroundColor(if (dark) Color.rgb(15, 25, 42) else Color.rgb(242, 247, 255))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val heading = TextView(this).apply {
            text = "Your windows  •  ${tabs.size}"
            textSize = 20f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(if (dark) Color.WHITE else Color.rgb(24, 39, 64))
        }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val add = button("＋ New") { dialogRef?.dismiss(); newTab("https://www.google.com", false) }
        header.addView(add)
        panel.addView(header)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tabs.forEachIndexed { index, tab ->
            val card = MaterialCardView(this).apply {
                radius = dp(18).toFloat()
                cardElevation = dp(3).toFloat()
                strokeWidth = dp(1)
                strokeColor = if (index == active) Color.rgb(54, 126, 238) else if (dark) Color.rgb(65, 81, 105) else Color.rgb(220, 229, 242)
                setCardBackgroundColor(if (dark) Color.rgb(30, 44, 65) else Color.WHITE)
                useCompatPadding = true
                setOnClickListener { dialogRef?.dismiss(); switchTab(index) }
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(10), dp(8), dp(10)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this).apply {
                text = (if (index == active) "●  " else "") + (tab.web.title?.takeIf { it.isNotBlank() } ?: "New window ${index + 1}") + if (tab.privateMode) "  •  Incognito" else ""
                textSize = 15f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(if (dark) Color.WHITE else Color.rgb(24, 39, 64))
            }
            val url = TextView(this).apply { text = tab.url; textSize = 11f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; setTextColor(if (dark) Color.LTGRAY else Color.GRAY) }
            info.addView(title); info.addView(url)
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val close = TextView(this).apply { text = "✕"; textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8)); setTextColor(if (dark) Color.WHITE else Color.DKGRAY); setOnClickListener { closeTabAt(index); dialogRef?.dismiss(); showTabs() } }
            row.addView(close)
            card.addView(row)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        scroll.addView(list)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        dialogRef = AlertDialog.Builder(this).setView(panel).setNegativeButton("Done", null).create()
        dialogRef?.show()
    }
    private fun closeTabAt(index: Int) {
        if (index !in tabs.indices) return
        if (tabs.size <= 1) {
            tabs[0].web.loadUrl("https://www.google.com")
            tabs[0].url = "https://www.google.com"
            return
        }
        val removed = tabs.removeAt(index)
        webHost.removeView(removed.web)
        removed.web.stopLoading()
        removed.web.destroy()
        if (index < active) active-- else if (index == active) active = (active - 1).coerceAtLeast(0)
        switchTab(active)
    }
    private fun closeCurrentTab() {
        if (tabs.size <= 1) { tabs[0].web.loadUrl("https://www.google.com"); tabs[0].url = "https://www.google.com"; return }
        val removed = tabs.removeAt(active)
        webHost.removeView(removed.web)
        removed.web.stopLoading(); removed.web.destroy()
        active = (active - 1).coerceAtLeast(0)
        switchTab(active)
    }
    private fun showList(title: String, values: Set<String>) {
        val items = values.toList().sortedDescending()
        if (items.isEmpty()) { Toast.makeText(this, "Nothing here yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which -> navigate(items[which]) }
            .setPositiveButton("Clear") { _, _ ->
                if (title == "History") prefs.edit().remove("history").apply()
                if (title == "Bookmarks") prefs.edit().remove("bookmarks").apply()
            }.show()
    }
    private fun showMenu() {
        val items = arrayOf("New incognito tab", "Bookmarks", "History", "Downloads", "Desktop site: ${if (desktop) "ON" else "OFF"}", "Ad blocking: ${if (adBlock) "ON" else "OFF"}", "Dark mode: ${if (dark) "ON" else "OFF"}", "Settings / About")
        AlertDialog.Builder(this).setTitle("Z-Internet menu").setItems(items) { _, which ->
            when (which) {
                0 -> newTab("https://www.google.com", true)
                1 -> showList("Bookmarks", bookmarks)
                2 -> showList("History", history)
                3 -> startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                4 -> { desktop = !desktop; prefs.edit().putBoolean("desktop", desktop).apply(); reloadWithSettings() }
                5 -> { adBlock = !adBlock; prefs.edit().putBoolean("adblock", adBlock).apply(); Toast.makeText(this, "Ad blocking ${if (adBlock) "on" else "off"}", Toast.LENGTH_SHORT).show() }
                6 -> { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); recreate() }
                7 -> showSettings()
            }
        }.show()
    }
    private fun reloadWithSettings() {
        tabs.forEach { tab ->
            val url = tab.url
            tab.web.settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this)
            tab.web.reload()
        }
    }
    private fun showSettings() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(8))
        }
        val currentScale = prefs.getInt("page_scale", 100).coerceIn(50, 200)
        val valueLabel = TextView(this).apply {
            text = "Page / Window scale: ${currentScale}%"
            textSize = 16f
        }
        wrap.addView(valueLabel)
        val scale = SeekBar(this).apply {
            max = 150
            progress = currentScale - 50
        }
        scale.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                valueLabel.text = "Page / Window scale: ${progress + 50}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        wrap.addView(scale)
        AlertDialog.Builder(this).setTitle("Settings • Z-Internet")
            .setView(wrap)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Apply") { _, _ ->
                val zoom = scale.progress + 50
                prefs.edit().putInt("page_scale", zoom).apply()
                tabs.forEach { it.web.settings.textZoom = zoom }
                Toast.makeText(this, "Page scale set to ${zoom}%", Toast.LENGTH_SHORT).show()
            }.show()
    }
    override fun onBackPressed() {
        val web = tabs.getOrNull(active)?.web
        if (web?.canGoBack() == true) web.goBack() else if (tabs.size > 1) closeCurrentTab() else super.onBackPressed()
    }
    override fun onDestroy() {
        tabs.forEach { it.web.stopLoading(); it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }
}
