package com.zinternet.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.setPadding
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {
    private data class BrowserTab(val web: WebView, var url: String, val privateMode: Boolean)
    private val tabs = mutableListOf<BrowserTab>()
    private var active = 0
    private lateinit var root: LinearLayout
    private lateinit var address: TextInputEditText
    private lateinit var webHost: FrameLayout
    private lateinit var tabLabel: TextView
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("z_internet", MODE_PRIVATE) }
    private val history get() = prefs.getStringSet("history", emptySet())!!.toMutableSet()
    private val bookmarks get() = prefs.getStringSet("bookmarks", emptySet())!!.toMutableSet()
    private var dark = false
    private var desktop = false
    private var adBlock = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dark = prefs.getBoolean("dark", false)
        desktop = prefs.getBoolean("desktop", false)
        adBlock = prefs.getBoolean("adblock", true)
        AppCompatDelegate.setDefaultNightMode(if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        buildShell()
        newTab("https://www.google.com", false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(text: String, onClick: () -> Unit): MaterialButton =
        MaterialButton(this).apply {
            this.text = text
            isAllCaps = false
            cornerRadius = dp(16)
            setOnClickListener { onClick() }
        }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (dark) Color.rgb(15, 23, 42) else Color.rgb(245, 248, 255))
            setPadding(dp(12))
        }
        val brand = TextView(this).apply {
            text = "Z-Internet   •   Fast  Smart  Secure"
            textSize = 18f
            setTextColor(if (dark) Color.WHITE else Color.rgb(20, 47, 91))
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        root.addView(brand)
        val addressCard = MaterialCardView(this).apply {
            radius = dp(24).toFloat()
            cardElevation = dp(1).toFloat()
            setCardBackgroundColor(if (dark) Color.rgb(30, 41, 59) else Color.WHITE)
        }
        val addressRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), 0, dp(4), 0) }
        address = TextInputEditText(this).apply {
            hint = "Search or enter website"
            singleLine = true
            textSize = 15f
            setTextColor(if (dark) Color.WHITE else Color.BLACK)
            setHintTextColor(Color.GRAY)
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.TRANSPARENT)
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) { navigate(text?.toString().orEmpty()); true } else false
            }
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, dp(52), 1f))
        addressRow.addView(button("GO") { navigate(address.text?.toString().orEmpty()) })
        addressCard.addView(addressRow)
        root.addView(addressCard)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        webHost = FrameLayout(this)
        root.addView(webHost, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf(
            "←" to { goBack() }, "→" to { goForward() }, "＋" to { newTab("https://www.google.com", false) },
            "Tabs" to { showTabs() }, "★" to { toggleBookmark() }, "⋮" to { showMenu() }
        ).forEach { (label, action) -> nav.addView(button(label, action), LinearLayout.LayoutParams(0, dp(48), 1f)) }
        root.addView(nav)
        tabLabel = TextView(this).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY)
            setPadding(0, dp(3), 0, dp(2))
        }
        root.addView(tabLabel)
        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(privateMode: Boolean): WebView = WebView(this).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.cacheMode = if (privateMode) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this@MainActivity).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this@MainActivity)
        if (privateMode) {
            clearCache(true)
            clearHistory()
            settings.saveFormData = false
        }
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) return false
                return true
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock && !privateMode) {
                    val host = request?.url?.host?.lowercase().orEmpty()
                    if (blockedHosts.any { host == it || host.endsWith(".$it") }) {
                        return WebResourceResponse("text/plain", "utf-8", 204, "Blocked", emptyMap(), null)
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                progress.visibility = View.VISIBLE
                progress.progress = 5
                address.setText(url.orEmpty())
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                url?.let {
                    val tab = tabs.getOrNull(active)
                    if (tab?.web === view) tab.url = it
                    if (tab?.privateMode == false) saveHistory(it)
                    address.setText(it)
                }
                updateTabLabel()
            }
        }
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
            override fun onReceivedTitle(view: WebView?, title: String?) { updateTabLabel(title) }
        }
        setDownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimeType)
                request.addRequestHeader("User-Agent", settings.userAgentString)
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                request.setDescription("Downloading with Z-Internet")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this@MainActivity, "Download started", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Download failed", Toast.LENGTH_SHORT).show() }
        }
    }

    private val blockedHosts = setOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "ads.yahoo.com", "adnxs.com", "taboola.com", "outbrain.com")
    private fun newTab(url: String, privateMode: Boolean) {
        val web = createWebView(privateMode)
        tabs.add(BrowserTab(web, url, privateMode))
        switchTab(tabs.lastIndex)
        web.loadUrl(url)
    }
    private fun switchTab(index: Int) {
        if (index !in tabs.indices) return
        active = index
        webHost.removeAllViews()
        val web = tabs[index].web
        (web.parent as? ViewGroup)?.removeView(web)
        webHost.addView(web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tabs[index].url)
        updateTabLabel()
    }
    private fun navigate(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") -> "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
            else -> "https://$value"
        }
        tabs.getOrNull(active)?.let { it.url = url; it.web.loadUrl(url) }
    }
    private fun goBack() { tabs.getOrNull(active)?.web?.let { if (it.canGoBack()) it.goBack() else Toast.makeText(this, "No previous page", Toast.LENGTH_SHORT).show() } }
    private fun goForward() { tabs.getOrNull(active)?.web?.let { if (it.canGoForward()) it.goForward() else Toast.makeText(this, "No next page", Toast.LENGTH_SHORT).show() } }
    private fun updateTabLabel(title: String? = null) {
        tabLabel.text = "${title ?: tabs.getOrNull(active)?.web?.title ?: "New tab"}   •   ${active + 1}/${tabs.size}" +
            if (tabs.getOrNull(active)?.privateMode == true) "   •   Incognito" else ""
    }
    private fun saveHistory(url: String) {
        if (!url.startsWith("http")) return
        val set = history
        set.add(url)
        prefs.edit().putStringSet("history", set).apply()
    }
    private fun toggleBookmark() {
        val url = tabs.getOrNull(active)?.url ?: return
        val set = bookmarks
        if (!set.add(url)) set.remove(url)
        prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, if (url in set) "Bookmarked" else "Bookmark removed", Toast.LENGTH_SHORT).show()
    }
    private fun showTabs() {
        val names = tabs.mapIndexed { i, t -> "${i + 1}. ${t.web.title ?: t.url}" + if (t.privateMode) " (Incognito)" else "" }.toMutableList()
        names.add("＋ New tab")
        AlertDialog.Builder(this).setTitle("Tabs (${tabs.size})").setItems(names.toTypedArray()) { _, which ->
            if (which == tabs.size) newTab("https://www.google.com", false) else switchTab(which)
        }.setNeutralButton("Close current") { _, _ -> closeCurrentTab() }.show()
    }
    private fun closeCurrentTab() {
        if (tabs.size <= 1) { tabs[0].web.loadUrl("https://www.google.com"); tabs[0].url = "https://www.google.com"; return }
        val removed = tabs.removeAt(active)
        webHost.removeView(removed.web)
        removed.web.stopLoading(); removed.web.destroy()
        active = (active - 1).coerceAtLeast(0)
        switchTab(active)
    }
    private fun showList(title: String, values: Set<String>) {
        val items = values.toList().sortedDescending()
        if (items.isEmpty()) { Toast.makeText(this, "Nothing here yet", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which -> navigate(items[which]) }
            .setPositiveButton("Clear") { _, _ ->
                if (title == "History") prefs.edit().remove("history").apply()
                if (title == "Bookmarks") prefs.edit().remove("bookmarks").apply()
            }.show()
    }
    private fun showMenu() {
        val items = arrayOf("New incognito tab", "Bookmarks", "History", "Downloads", "Desktop site: ${if (desktop) "ON" else "OFF"}", "Ad blocking: ${if (adBlock) "ON" else "OFF"}", "Dark mode: ${if (dark) "ON" else "OFF"}", "Settings / About")
        AlertDialog.Builder(this).setTitle("Z-Internet menu").setItems(items) { _, which ->
            when (which) {
                0 -> newTab("https://www.google.com", true)
                1 -> showList("Bookmarks", bookmarks)
                2 -> showList("History", history)
                3 -> startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                4 -> { desktop = !desktop; prefs.edit().putBoolean("desktop", desktop).apply(); reloadWithSettings() }
                5 -> { adBlock = !adBlock; prefs.edit().putBoolean("adblock", adBlock).apply(); Toast.makeText(this, "Ad blocking ${if (adBlock) "on" else "off"}", Toast.LENGTH_SHORT).show() }
                6 -> { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); recreate() }
                7 -> showSettings()
            }
        }.show()
    }
    private fun reloadWithSettings() {
        tabs.forEach { tab ->
            val url = tab.url
            tab.web.settings.userAgentString = if (desktop) WebSettings.getDefaultUserAgent(this).replace("Android", "X11; Linux x86_64").replace("Mobile", "") else WebSettings.getDefaultUserAgent(this)
            tab.web.reload()
        }
    }
    private fun showSettings() {
        AlertDialog.Builder(this).setTitle("Z-Internet Browser")
            .setMessage("Version 1.0.0\\n\\nAdvanced Android browser built with WebView. Includes tabs, bookmarks, history, downloads, incognito sessions, desktop user-agent mode and basic request blocking.\\n\\nNote: request blocking uses a small built-in domain list; it is not a full filter-list ad blocker.")
            .setPositiveButton("OK", null).show()
    }
    override fun onBackPressed() {
        val web = tabs.getOrNull(active)?.web
        if (web?.canGoBack() == true) web.goBack() else if (tabs.size > 1) closeCurrentTab() else super.onBackPressed()
    }
    override fun onDestroy() {
        tabs.forEach { it.web.stopLoading(); it.web.destroy() }
        tabs.clear()
        super.onDestroy()
    }
}
